class Account:
    def __init__(self,fname,lname,ssn,deposit):
        self.fname=fname
        self.lname=lname
        self.ssn=ssn
        self.__balance=deposit
        self.user_id=fname+'123'
        self.password='123456'

    def getBalance(self):
        return self.__balance

    def setBalance(self,amount):
        self.amount=amount
        self.__balance=self.__balance+self.amount