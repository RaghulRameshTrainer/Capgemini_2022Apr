from bank import Account

acc_1=Account('Raghul','Ramesh',"9843843995",1000)
print("Net banking User ID:",acc_1.user_id)
print("Initial Password:",acc_1.password)
# print("My Account Balance: ",acc_1.__balance)
# acc_1.__balance=50000000
# print("My Account Balance: ",acc_1.__balance)
print("My Account Balance: ",acc_1.getBalance())
acc_1.setBalance(1000)
print("My Account Balance: ",acc_1.getBalance())